def get_help_message():
    print('Invalid argument entry. Use only 2 or 3 arguments')
    print(' Use "myaesprog.py {input file name} {encrypted_name} {key_file}"')
    print('or use myaesprog.py {encrypted_name} {key_file}')